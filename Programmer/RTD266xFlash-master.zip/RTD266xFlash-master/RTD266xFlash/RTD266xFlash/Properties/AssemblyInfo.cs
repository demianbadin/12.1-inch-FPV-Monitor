﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("RTD266xFlash")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("RTD266xFlash")]
[assembly: AssemblyCopyright("Copyright © 2018-2021 floppes")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("5ddd2333-b8c0-4077-9f3d-2d1169f0559c")]
[assembly: AssemblyVersion("2.9.1.0")]
[assembly: AssemblyFileVersion("2.9.1.0")]
